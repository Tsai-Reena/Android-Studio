package com.example.ticket_kiosk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void show(View v){
        TextView txv=(TextView)findViewById(R.id.txv);
        RadioGroup ticketType = (RadioGroup) findViewById(R.id.ticketType);

        // 依選取項目顯示不同訊息
        switch(ticketType.getCheckedRadioButtonId()){
            case R.id.adult:	// 選全票
                txv.setText("Adult");
                break;
            case R.id.child:	// 選半票
                txv.setText("Student");
                break;
            case R.id.senior:	// 選敬老票
                txv.setText("Elder");
                break;
        }
    }
}
